package com.quack.quackmacehelper.gui;

import com.quack.quackmacehelper.config.ModConfig;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class QuackMaceScreen extends class_437 {

    // Layout
    private static final int W = 340, H = 420;
    private static final int SIDE = 115;
    private int px, py;

    private int tab = 0;
    private boolean awaitingKey = false;
    private String awaitingLabel = "";
    private Consumer<Integer> awaitingCallback;

    private final String[] TABS = {
        "General", "Aim Assist", "Breach Swap", "Stun Slam",
        "Pearl Catch", "Shield Drain", "Elytra Swap",
        "Wind Tackle", "Always Shield"
    };

    public QuackMaceScreen() { super(class_2561.method_43470("QuackMaceHelper")); }

    @Override
    protected void method_25426() {
        px = (field_22789 - W) / 2;
        py = (field_22790 - H) / 2;
        rebuild();
    }

    private void rebuild() {
        method_37067();
        // Sidebar tab buttons
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            method_37063(class_4185.method_46430(class_2561.method_43470(TABS[i]),
                    b -> { tab = idx; rebuild(); })
                .method_46434(px + 4, py + 28 + i * 24, SIDE - 6, 20).method_46431());
        }
        buildContent();
    }

    private void buildContent() {
        ModConfig cfg = ModConfig.get();
        int cx = px + SIDE + 6;
        int cy = py + 32;

        switch (tab) {
            case 0 -> buildGeneral(cx, cy, cfg);
            case 1 -> buildAimAssist(cx, cy, cfg);
            case 2 -> buildBreachSwap(cx, cy, cfg);
            case 3 -> buildStunSlam(cx, cy, cfg);
            case 4 -> buildPearlCatch(cx, cy, cfg);
            case 5 -> buildShieldDrain(cx, cy, cfg);
            case 6 -> buildElytraSwap(cx, cy, cfg);
            case 7 -> buildWindTackle(cx, cy, cfg);
            case 8 -> buildAlwaysShield(cx, cy, cfg);
        }
    }

    // ── General ──────────────────────────────────────────────────────────
    private void buildGeneral(int x, int y, ModConfig cfg) {
        addToggle(x, y, "Target Players", cfg.targetPlayers, v -> { cfg.targetPlayers = v; save(); });
        addToggle(x, y + 24, "Target Mobs", cfg.targetMobs, v -> { cfg.targetMobs = v; save(); });
        addToggle(x, y + 48, "Target Animals", cfg.targetAnimals, v -> { cfg.targetAnimals = v; save(); });
        addKeybind(x, y + 80, "Open Menu Key", cfg.keybinds.openGui, v -> { cfg.keybinds.openGui = v; save(); });
    }

    // ── Aim Assist ───────────────────────────────────────────────────────
    private void buildAimAssist(int x, int y, ModConfig cfg) {
        addToggle(x, y, "Enabled", cfg.aimAssist.enabled, v -> { cfg.aimAssist.enabled = v; save(); });
        addKeybind(x, y + 26, "Toggle Key", cfg.keybinds.toggleAimAssist, v -> { cfg.keybinds.toggleAimAssist = v; save(); });
        addSliderInt(x, y + 52, "Range: " + (int)cfg.aimAssist.range + " blocks",
                (int)cfg.aimAssist.range, 1, 8, v -> { cfg.aimAssist.range = v; save(); rebuild(); });
        addSliderFloat(x, y + 76, "FOV: " + (int)cfg.aimAssist.fov + "°",
                cfg.aimAssist.fov, 60, 360, v -> { cfg.aimAssist.fov = v; save(); rebuild(); });
        addSliderFloat(x, y + 100, "Speed: " + (int)cfg.aimAssist.speed + "°/s",
                cfg.aimAssist.speed, 600, 7200, v -> { cfg.aimAssist.speed = v; save(); rebuild(); });
        addToggle(x, y + 126, "Speed Randomization", cfg.aimAssist.speedRandomization,
                v -> { cfg.aimAssist.speedRandomization = v; save(); });
    }

    // ── Breach Swap ──────────────────────────────────────────────────────
    private void buildBreachSwap(int x, int y, ModConfig cfg) {
        addToggle(x, y, "Enabled", cfg.breachSwap.enabled, v -> { cfg.breachSwap.enabled = v; save(); });
        addKeybind(x, y + 26, "Toggle Key", cfg.keybinds.toggleBreachSwap, v -> { cfg.keybinds.toggleBreachSwap = v; save(); });
        label(x, y + 56, "§7Hits with mace on sword/axe attack,");
        label(x, y + 68, "§7then switches back to sword.");
    }

    // ── Stun Slam ────────────────────────────────────────────────────────
    private void buildStunSlam(int x, int y, ModConfig cfg) {
        addToggle(x, y, "Enabled", cfg.stunSlam.enabled, v -> { cfg.stunSlam.enabled = v; save(); });
        addKeybind(x, y + 26, "Toggle Key", cfg.keybinds.toggleStunSlam, v -> { cfg.keybinds.toggleStunSlam = v; save(); });
        label(x, y + 56, "§7When opponent has shield up while");
        label(x, y + 68, "§7falling: sword → axe → mace in 2 ticks.");
        label(x, y + 84, "§cAuto-off when Shield Drain is on.");
    }

    // ── Pearl Catch ──────────────────────────────────────────────────────
    private void buildPearlCatch(int x, int y, ModConfig cfg) {
        addToggle(x, y, "Enabled", cfg.pearlCatch.enabled, v -> { cfg.pearlCatch.enabled = v; save(); });
        addKeybind(x, y + 26, "Toggle Key", cfg.keybinds.togglePearlCatch, v -> { cfg.keybinds.togglePearlCatch = v; save(); });
        addSliderInt(x, y + 52, "Throw Delay: " + cfg.pearlCatch.delayTicks + " tick(s)",
                cfg.pearlCatch.delayTicks, 1, 3, v -> { cfg.pearlCatch.delayTicks = v; save(); rebuild(); });
        addSliderInt(x, y + 76, "Trigger Height: " + cfg.pearlCatch.triggerHeight + " blocks",
                cfg.pearlCatch.triggerHeight, 5, 20, v -> { cfg.pearlCatch.triggerHeight = v; save(); rebuild(); });
    }

    // ── Shield Drain ─────────────────────────────────────────────────────
    private void buildShieldDrain(int x, int y, ModConfig cfg) {
        addToggle(x, y, "Enabled", cfg.shieldDraining.enabled, v -> { cfg.shieldDraining.enabled = v; save(); });
        addKeybind(x, y + 26, "Toggle Key", cfg.keybinds.toggleShieldDraining, v -> { cfg.keybinds.toggleShieldDraining = v; save(); });
        addSliderInt(x, y + 52, "CPS: " + cfg.shieldDraining.cps,
                cfg.shieldDraining.cps, 5, 150, v -> { cfg.shieldDraining.cps = v; save(); rebuild(); });
        label(x, y + 82, "§cDisables Stun Slam while active.");
    }

    // ── Elytra Swap ──────────────────────────────────────────────────────
    private void buildElytraSwap(int x, int y, ModConfig cfg) {
        addToggle(x, y, "Enabled", cfg.elytraSwapper.enabled, v -> { cfg.elytraSwapper.enabled = v; save(); });
        addKeybind(x, y + 26, "Toggle Key", cfg.keybinds.toggleElytraSwapper, v -> { cfg.keybinds.toggleElytraSwapper = v; save(); });
        addSliderFloat(x, y + 52, "FOV: " + (int)cfg.elytraSwapper.fov + "°",
                cfg.elytraSwapper.fov, 60, 360, v -> { cfg.elytraSwapper.fov = v; save(); rebuild(); });
        addToggle(x, y + 78, "Auto Aim", cfg.elytraSwapper.autoAim, v -> { cfg.elytraSwapper.autoAim = v; save(); });
        label(x, y + 106, "§7Equips chestplate, hits with mace");
        label(x, y + 118, "§74-5 times while gliding.");
    }

    // ── Wind Charge Tackle ───────────────────────────────────────────────
    private void buildWindTackle(int x, int y, ModConfig cfg) {
        addToggle(x, y, "Enabled", cfg.windChargeTackle.enabled, v -> { cfg.windChargeTackle.enabled = v; save(); });
        addKeybind(x, y + 26, "Toggle Key", cfg.keybinds.toggleWindChargeTackle, v -> { cfg.keybinds.toggleWindChargeTackle = v; save(); });
        label(x, y + 56, "§7Throws 1 wind charge at players");
        label(x, y + 68, "§7falling/gliding toward you (10 block radius).");
    }

    // ── Always On Shield ─────────────────────────────────────────────────
    private void buildAlwaysShield(int x, int y, ModConfig cfg) {
        addToggle(x, y, "Enabled", cfg.alwaysOnShield.enabled, v -> { cfg.alwaysOnShield.enabled = v; save(); });
        addKeybind(x, y + 26, "Toggle Key", cfg.keybinds.toggleAlwaysOnShield, v -> { cfg.keybinds.toggleAlwaysOnShield = v; save(); });
        label(x, y + 56, "§7Equips shield (or totem) when a player");
        label(x, y + 68, "§7is falling/flying toward you.");
        label(x, y + 84, "§7If Wind Tackle is on, fires wind charge first.");
    }

    // ── Widget helpers ───────────────────────────────────────────────────

    private void addToggle(int x, int y, String name, boolean current, Consumer<Boolean> cb) {
        method_37063(class_4185.method_46430(
                class_2561.method_43470(name + ": " + (current ? "§aON" : "§cOFF")),
                b -> { cb.accept(!current); rebuild(); })
            .method_46434(x, y, 190, 20).method_46431());
    }

    private void addKeybind(int x, int y, String name, int keyCode, Consumer<Integer> cb) {
        String keyName = keyCode == -1 ? "§7[Unbound]"
                : "§e" + class_3675.method_15985(new class_11908(keyCode, 0, 0)).method_27445().getString();
        // Set button
        method_37063(class_4185.method_46430(
                class_2561.method_43470(name + ": " + keyName),
                b -> {
                    awaitingKey = true;
                    awaitingLabel = name;
                    awaitingCallback = cb;
                    rebuild();
                })
            .method_46434(x, y, 155, 20).method_46431());
        // Reset button
        method_37063(class_4185.method_46430(class_2561.method_43470("§cReset"),
                b -> { cb.accept(-1); rebuild(); })
            .method_46434(x + 158, y, 40, 20).method_46431());
    }

    private void addSliderInt(int x, int y, String label, int current, int min, int max, Consumer<Integer> cb) {
        method_37063(new class_357(x, y, 198, 18, class_2561.method_43470(label),
                (double)(current - min) / (max - min)) {
            @Override protected void method_25346() {
                int v = (int)Math.round(field_22753 * (max - min)) + min;
                method_25355(class_2561.method_43470(label.replaceAll("\\d+", String.valueOf(v))));
            }
            @Override protected void method_25344() {
                cb.accept((int)Math.round(field_22753 * (max - min)) + min);
            }
        });
    }

    private void addSliderFloat(int x, int y, String label, float current, float min, float max, Consumer<Float> cb) {
        method_37063(new class_357(x, y, 198, 18, class_2561.method_43470(label),
                (double)(current - min) / (max - min)) {
            @Override protected void method_25346() {
                float v = (float)(field_22753 * (max - min)) + min;
                method_25355(class_2561.method_43470(label.replaceAll("\\d+", String.valueOf((int)v))));
            }
            @Override protected void method_25344() {
                cb.accept((float)(field_22753 * (max - min)) + min);
            }
        });
    }

    private final List<String[]> labels = new ArrayList<>();
    private void label(int x, int y, String text) {
        labels.add(new String[]{String.valueOf(x), String.valueOf(y), text});
    }

    // ── Key capture ──────────────────────────────────────────────────────

    @Override
    public boolean method_25404(class_11908 keyInput) {
        int keyCode = keyInput.comp_4795();
        if (awaitingKey) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                awaitingKey = false;
                rebuild();
                return true;
            }
            awaitingCallback.accept(keyCode);
            awaitingKey = false;
            rebuild();
            return true;
        }
        return super.method_25404(keyInput);
    }

    // ── Render ───────────────────────────────────────────────────────────

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        method_25420(ctx, mx, my, delta);

        // Main panel
        ctx.method_25294(px, py, px + W, py + H, 0xE8101010);
        // Sidebar
        ctx.method_25294(px, py, px + SIDE, py + H, 0xE8181818);
        // Title bar
        ctx.method_25294(px, py, px + W, py + 26, 0xFF1A1A2E);
        ctx.method_25300(field_22793, "§eQuackMaceHelper", px + W / 2, py + 8, 0xFFFFFF);

        // Active tab highlight
        ctx.method_25294(px + 2, py + 28 + tab * 24, px + SIDE - 2, py + 48 + tab * 24, 0x44AAAAFF);

        // "Press a key..." overlay
        if (awaitingKey) {
            ctx.method_25294(px + SIDE, py + 26, px + W, py + H, 0xCC000000);
            ctx.method_25300(field_22793,
                    "§eSetting: " + awaitingLabel, px + SIDE + (W - SIDE) / 2, py + H / 2 - 10, 0xFFFFFF);
            ctx.method_25300(field_22793,
                    "§7Press any key... (ESC to cancel)", px + SIDE + (W - SIDE) / 2, py + H / 2 + 4, 0xAAAAAA);
        }

        // Draw labels
        for (String[] lbl : labels) {
            ctx.method_25303(field_22793, lbl[2], Integer.parseInt(lbl[0]), Integer.parseInt(lbl[1]), 0xAAAAAA);
        }
        labels.clear();

        super.method_25394(ctx, mx, my, delta);
    }

    @Override public boolean method_25421() { return false; }

    private void save() { ModConfig.save(); }
}
