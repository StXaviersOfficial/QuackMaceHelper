package com.quack.quackmacehelper.keybind;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class KeyBindings {

    public static final class_304.class_11900 CATEGORY =
            new class_304.class_11900(class_2960.method_60655("quackmacehelper", "main"));

    public static class_304 openGui;
    public static class_304 toggleAimAssist;
    public static class_304 toggleBreachSwap;
    public static class_304 toggleStunSlam;
    public static class_304 togglePearlCatch;
    public static class_304 toggleShieldDraining;
    public static class_304 toggleElytraSwapper;
    public static class_304 toggleWindChargeTackle;
    public static class_304 toggleAlwaysOnShield;

    public static void register() {
        openGui = reg("open_gui", GLFW.GLFW_KEY_UNKNOWN);
        toggleAimAssist = reg("toggle_aimassist", GLFW.GLFW_KEY_N);
        toggleBreachSwap = reg("toggle_breachswap", GLFW.GLFW_KEY_UNKNOWN);
        toggleStunSlam = reg("toggle_stunslam", GLFW.GLFW_KEY_UNKNOWN);
        togglePearlCatch = reg("toggle_pearlcatch", GLFW.GLFW_KEY_UNKNOWN);
        toggleShieldDraining = reg("toggle_shielddraining", GLFW.GLFW_KEY_UNKNOWN);
        toggleElytraSwapper = reg("toggle_elytraswapper", GLFW.GLFW_KEY_UNKNOWN);
        toggleWindChargeTackle = reg("toggle_windchargetackle", GLFW.GLFW_KEY_UNKNOWN);
        toggleAlwaysOnShield = reg("toggle_alwaysonshield", GLFW.GLFW_KEY_UNKNOWN);
    }

    private static class_304 reg(String name, int defaultKey) {
        return KeyBindingHelper.registerKeyBinding(new class_304(
                "key.quackmacehelper." + name,
                class_3675.class_307.field_1668,
                defaultKey,
                CATEGORY
        ));
    }
}
