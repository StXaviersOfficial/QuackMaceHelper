package com.quack.quackmacehelper.mixin;

import com.quack.quackmacehelper.feature.BreachSwapFeature;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_636.class)
public class ClientPlayerEntityMixin {
    @Inject(method = "attackEntity", at = @At("HEAD"))
    private void onAttack(class_1657 player, class_1297 target, CallbackInfo ci) {
        if (!(target instanceof class_1309 living)) return;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;
        BreachSwapFeature.onAttack(client, living);
    }
}
