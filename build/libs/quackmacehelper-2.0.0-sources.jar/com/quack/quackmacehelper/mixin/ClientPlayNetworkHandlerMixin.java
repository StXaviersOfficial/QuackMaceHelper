package com.quack.quackmacehelper.mixin;

import com.quack.quackmacehelper.gui.QuackMaceScreen;
import net.minecraft.class_310;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_408.class)
public class ClientPlayNetworkHandlerMixin {
    @Inject(method = "sendMessage", at = @At("HEAD"), cancellable = true)
    private void onSendMessage(String message, boolean addToHistory, CallbackInfo ci) {
        if (message.trim().equalsIgnoreCase("/quackmace")) {
            class_310.method_1551().method_1507(new QuackMaceScreen());
            ci.cancel();
        }
    }
}
