package com.quack.quackmacehelper.mixin;

import com.quack.quackmacehelper.feature.*;
import net.minecraft.class_310;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class GameRendererMixin {
    @Shadow @Final class_310 client;

    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(class_9779 counter, boolean tick, CallbackInfo ci) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        if (!tick) return;

        // AimAssist target finding + rotation calc happens on game tick
        AimAssistFeature.onGameTick(client);

        BreachSwapFeature.tick(client);
        StunSlamFeature.tick(client);
        ShieldDrainingFeature.tick(client);
        ElytraSwapperFeature.tick(client);
        PearlCatchFeature.tick(client);
        WindChargeTackleFeature.tick(client);
        AlwaysOnShieldFeature.tick(client);
    }
}
