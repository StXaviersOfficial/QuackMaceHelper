package com.quack.quackmacehelper.feature;

import com.quack.quackmacehelper.config.ModConfig;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class AimAssistFeature {

    private static class_1309 currentTarget = null;

    // Desired rotation calculated each game tick
    private static float nextYaw = 0f;
    private static float nextPitch = 0f;
    private static boolean hasTarget = false;

    /**
     * Called every GAME TICK (20/s). Finds target and calculates desired rotation.
     */
    public static void onGameTick(class_310 client) {
        ModConfig cfg = ModConfig.get();
        hasTarget = false;

        if (!cfg.aimAssist.enabled) { currentTarget = null; return; }
        if (client.field_1724 == null || client.field_1687 == null) return;
        if (client.field_1755 != null) return;

        // Find/revalidate target
        if (currentTarget == null || !currentTarget.method_5805()
                || currentTarget.method_5739(client.field_1724) > cfg.aimAssist.range) {
            currentTarget = TargetHelper.findTarget(client, cfg.aimAssist.range);
        }
        if (currentTarget == null) return;

        // FOV check
        if (!TargetHelper.isInFov(client, currentTarget, cfg.aimAssist.fov)) {
            currentTarget = null;
            return;
        }

        // Calculate desired rotation toward target eye
        class_243 eye = client.field_1724.method_33571();
        class_243 targetPos = new class_243(
                currentTarget.method_23317(),
                currentTarget.method_23320(),
                currentTarget.method_23321()
        );
        class_243 delta = targetPos.method_1020(eye);
        double hDist = Math.sqrt(delta.field_1352 * delta.field_1352 + delta.field_1350 * delta.field_1350);

        nextYaw   = (float) Math.toDegrees(Math.atan2(-delta.field_1352, delta.field_1350));
        nextPitch = (float) -Math.toDegrees(Math.atan2(delta.field_1351, hDist));
        hasTarget = true;
    }

    /**
     * Called every MOUSE UPDATE (raw input hook via mixin).
     * Nudges mouse delta toward desired rotation — exactly like Wurst.
     * Returns adjusted [deltaX, deltaY].
     */
    public static double[] onMouseUpdate(class_310 client, double deltaX, double deltaY) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.aimAssist.enabled || !hasTarget || client.field_1724 == null) {
            return new double[]{deltaX, deltaY};
        }

        float curYaw   = client.field_1724.method_36454();
        float curPitch = client.field_1724.method_36455();

        // Max rotation per tick based on speed (20 tps base), with randomization
        float speed = cfg.aimAssist.speed;
        if (cfg.aimAssist.speedRandomization) {
            float variance = cfg.aimAssist.speedRandomRange;
            speed += (float)(Math.random() * 2 - 1) * variance;
            speed = Math.max(100f, speed);
        }
        float maxStep = speed / 20f;

        // Calculate how many degrees we need to turn
        float diffYaw   = class_3532.method_15393(nextYaw - curYaw);
        float diffPitch = class_3532.method_15393(nextPitch - curPitch);

        // Clamp to max step
        float stepYaw   = Math.abs(diffYaw)   < maxStep ? diffYaw   : Math.signum(diffYaw)   * maxStep;
        float stepPitch = Math.abs(diffPitch) < maxStep ? diffPitch : Math.signum(diffPitch) * maxStep;

        // Add our rotation nudge on top of player's own mouse input
        return new double[]{
                deltaX + stepYaw,
                deltaY + stepPitch
        };
    }

    /**
     * Direct aim used by ElytraSwapper, WindChargeTackle etc — NOT the smooth mouse method.
     * Sets yaw/pitch instantly.
     */
    public static void snapAimAt(class_310 client, class_1309 target) {
        if (client.field_1724 == null || target == null) return;
        class_243 eye = client.field_1724.method_33571();
        class_243 targetPos = new class_243(target.method_23317(), target.method_23320(), target.method_23321());
        class_243 delta = targetPos.method_1020(eye);
        double hDist = Math.sqrt(delta.field_1352 * delta.field_1352 + delta.field_1350 * delta.field_1350);
        float yaw   = (float) Math.toDegrees(Math.atan2(-delta.field_1352, delta.field_1350));
        float pitch = (float) -Math.toDegrees(Math.atan2(delta.field_1351, hDist));
        client.field_1724.method_36456(yaw);
        client.field_1724.method_36457(class_3532.method_15363(pitch, -90f, 90f));
    }

    /**
     * Smooth aim used by ElytraSwapper AutoAim — uses setYaw/setPitch with speed cap.
     */
    public static void smoothAimAt(class_310 client, class_1309 target,
                                    float degreesPerSecond, float deltaTime,
                                    boolean randomize, float randomRange) {
        if (client.field_1724 == null) return;
        class_243 eye = client.field_1724.method_33571();
        class_243 targetPos = new class_243(target.method_23317(), target.method_23320(), target.method_23321());
        class_243 delta = targetPos.method_1020(eye);
        double hDist = Math.sqrt(delta.field_1352 * delta.field_1352 + delta.field_1350 * delta.field_1350);
        float wantYaw   = (float) Math.toDegrees(Math.atan2(-delta.field_1352, delta.field_1350));
        float wantPitch = (float) -Math.toDegrees(Math.atan2(delta.field_1351, hDist));

        float speed = degreesPerSecond;
        if (randomize && randomRange > 0)
            speed = Math.max(100f, speed + (float)(Math.random() * 2 - 1) * randomRange);

        float maxStep = speed * deltaTime;
        float newYaw   = stepToward(client.field_1724.method_36454(), wantYaw, maxStep);
        float newPitch = class_3532.method_15363(stepToward(client.field_1724.method_36455(), wantPitch, maxStep), -90f, 90f);
        client.field_1724.method_36456(newYaw);
        client.field_1724.method_36457(newPitch);
    }

    private static float stepToward(float current, float target, float maxStep) {
        float diff = class_3532.method_15393(target - current);
        if (Math.abs(diff) <= maxStep) return target;
        return current + Math.signum(diff) * maxStep;
    }

    public static class_1309 getCurrentTarget() { return currentTarget; }
    public static void clearTarget() { currentTarget = null; hasTarget = false; }
    public static void forceTarget(class_1309 e) { currentTarget = e; }
}
