package com.quack.quackmacehelper.feature;

import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_5321;
import net.minecraft.class_746;
import net.minecraft.item.*;
import java.util.Optional;

public class InventoryHelper {

    // ── Slot finders ────────────────────────────────────────────────────────

    /** Returns hotbar slot (0-8) of first sword, or -1 */
    public static int findSwordSlot(class_746 player) {
        for (int i = 0; i < 9; i++) {
            if (player.method_31548().method_5438(i).method_31573(class_3489.field_42611)) return i;
        }
        return -1;
    }

    /** Returns hotbar slot of first axe, or -1 */
    public static int findAxeSlot(class_746 player) {
        for (int i = 0; i < 9; i++) {
            if (player.method_31548().method_5438(i).method_7909() instanceof class_1743) return i;
        }
        return -1;
    }

    /** Returns hotbar slot of mace with Breach enchantment, or -1 */
    public static int findBreachMaceSlot(class_746 player) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (isMace(stack) && hasEnchantmentType(stack, "breach")) return i;
        }
        return -1;
    }

    /** Returns hotbar slot of mace with Density enchantment, or -1 */
    public static int findDensityMaceSlot(class_746 player) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (isMace(stack) && hasEnchantmentType(stack, "density")) return i;
        }
        return -1;
    }

    /** Returns hotbar slot of any mace, or -1 */
    public static int findAnyMaceSlot(class_746 player) {
        for (int i = 0; i < 9; i++) {
            if (isMace(player.method_31548().method_5438(i))) return i;
        }
        return -1;
    }

    /** Returns hotbar slot of elytra chestplate item (held), or -1 */
    public static int findElytraInHotbar(class_746 player) {
        for (int i = 0; i < 9; i++) {
            if (player.method_31548().method_5438(i).method_31574(class_1802.field_8833)) return i;
        }
        return -1;
    }

    /** Returns hotbar slot of wind charge, or -1 */
    public static int findWindChargeSlot(class_746 player) {
        for (int i = 0; i < 9; i++) {
            class_1792 item = player.method_31548().method_5438(i).method_7909();
            if (item == class_1802.field_49098) return i;
        }
        return -1;
    }

    /** Returns hotbar slot of ender pearl, or -1 */
    public static int findEnderPearlSlot(class_746 player) {
        for (int i = 0; i < 9; i++) {
            if (player.method_31548().method_5438(i).method_7909() == class_1802.field_8634) return i;
        }
        return -1;
    }

    // ── Swap helpers ─────────────────────────────────────────────────────────

    /** Switches to hotbar slot instantly */
    public static void switchToSlot(class_310 client, int slot) {
        if (slot < 0 || slot > 8) return;
        client.field_1724.method_31548().method_61496(slot);
    }

    // ── Damage calculators ───────────────────────────────────────────────────

    /**
     * Calculates effective mace fall damage bonus for a given fall distance.
     * Breach reduces armor; Density adds flat damage per block fallen.
     * Returns expected damage for a rough comparison.
     */
    public static float estimateMaceDamage(class_746 player, int slot, double fallDistance, float targetArmor) {
        class_1799 stack = player.method_31548().method_5438(slot);
        if (!isMace(stack)) return 0f;

        float base = 6f; // base mace damage
        float fallBonus = (float) (Math.max(0, fallDistance - 1.5) * 3);

        int densityLevel = getEnchantmentLevel(stack, "density");
        int breachLevel = getEnchantmentLevel(stack, "breach");

        float densityBonus = (float) (densityLevel * fallDistance);
        float breachArmorReduction = breachLevel * 0.15f; // reduces armor effectiveness

        float effectiveArmor = targetArmor * (1f - breachArmorReduction);
        float rawDamage = base + fallBonus + densityBonus;
        float armorReduction = effectiveArmor / (effectiveArmor + 2f); // simplified

        return rawDamage * (1f - armorReduction * 0.5f);
    }

    /**
     * Picks the better mace slot (breach vs density) based on fall distance.
     * On ground (fallDistance < 2), always prefer breach.
     */
    public static int pickBestMaceSlot(class_746 player, double fallDistance, float targetArmor) {
        int breachSlot = findBreachMaceSlot(player);
        int densitySlot = findDensityMaceSlot(player);

        if (breachSlot == -1 && densitySlot == -1) return findAnyMaceSlot(player);
        if (breachSlot == -1) return densitySlot;
        if (densitySlot == -1) return breachSlot;

        // On ground or low fall → always breach
        if (fallDistance < 3) return breachSlot;

        float breachDmg = estimateMaceDamage(player, breachSlot, fallDistance, targetArmor);
        float densityDmg = estimateMaceDamage(player, densitySlot, fallDistance, targetArmor);
        return densityDmg > breachDmg ? densitySlot : breachSlot;
    }

    // ── Checks ───────────────────────────────────────────────────────────────

    public static boolean isMace(class_1799 stack) {
        return stack.method_7909() == class_1802.field_49814;
    }

    public static boolean isHoldingShield(net.minecraft.class_1309 entity) {
        return entity.method_6030().method_7909() == class_1802.field_8255 && entity.method_6039();
    }

    private static boolean hasEnchantmentType(class_1799 stack, String enchId) {
        return getEnchantmentLevel(stack, enchId) > 0;
    }

    private static int getEnchantmentLevel(class_1799 stack, String enchId) {
        var enchantments = class_1890.method_57532(stack);
        for (var entry : enchantments.method_57534()) {
            Optional<class_5321<class_1887>> key = entry.method_40230();
            if (key.isPresent() && key.get().method_29177().method_12832().contains(enchId)) {
                return enchantments.method_57536(entry);
            }
        }
        return 0;
    }
}
