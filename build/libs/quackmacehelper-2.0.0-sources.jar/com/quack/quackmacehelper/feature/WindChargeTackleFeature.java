package com.quack.quackmacehelper.feature;

import com.quack.quackmacehelper.config.ModConfig;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;

/**
 * WindChargeTackle: Detects players falling/gliding toward user within 10 blocks.
 * Aims precisely at their hitbox, throws exactly 1 wind charge.
 * Then if AlwaysOnShield is on, that takes over immediately after.
 */
public class WindChargeTackleFeature {

    private static boolean fired = false;
    private static class_1309 lastTarget = null;
    private static long lastFireMs = 0;
    private static final long COOLDOWN_MS = 3000; // 3 sec cooldown per target

    public static void tick(class_310 client) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.windChargeTackle.enabled) { reset(); return; }
        if (client.field_1724 == null) return;

        class_746 player = client.field_1724;

        // Find a player flying/falling toward us
        class_1309 threat = findThreat(client, cfg.windChargeTackle.radius);
        if (threat == null) { fired = false; lastTarget = null; return; }

        // Cooldown per target
        if (threat == lastTarget && System.currentTimeMillis() - lastFireMs < COOLDOWN_MS) return;

        // Must have wind charge
        int wcSlot = InventoryHelper.findWindChargeSlot(player);
        if (wcSlot == -1) return;

        // Aim precisely at their center/hitbox
        aimAtHitbox(client, player, threat);

        // Fire wind charge
        InventoryHelper.switchToSlot(client, wcSlot);
        client.field_1761.method_2919(player, class_1268.field_5808);

        lastTarget = threat;
        lastFireMs = System.currentTimeMillis();

        // Hand off to AlwaysOnShield immediately after if enabled
        if (cfg.alwaysOnShield.enabled) {
            AlwaysOnShieldFeature.activateFor(threat);
        }
    }

    private static class_1309 findThreat(class_310 client, float radius) {
        class_1309 t = TargetHelper.findPlayerTarget(client, radius);
        if (t == null) return null;
        // Must be falling or gliding
        boolean falling = !t.method_24828() && t.method_18798().field_1351 < -0.1;
        boolean gliding = t instanceof net.minecraft.class_1657 pe && pe.method_6128();
        if (!falling && !gliding) return null;
        // Must be moving toward player
        if (!TargetHelper.isMovingToward(client, t)) return null;
        return t;
    }

    private static void aimAtHitbox(class_310 client, class_746 player, class_1309 target) {
        // Predict position: estimate wind charge travel ticks
        double dist = player.method_5739(target);
        int travelTicks = Math.max(1, (int)(dist / 1.5));
        class_243 vel = target.method_18798();
        class_243 future = target.method_73189()
                .method_1031(vel.field_1352 * travelTicks, vel.field_1351 * travelTicks, vel.field_1350 * travelTicks)
                .method_1031(0, target.method_17682() / 2.0, 0); // aim at center

        class_243 d = future.method_1020(player.method_33571());
        double hDist = Math.sqrt(d.field_1352 * d.field_1352 + d.field_1350 * d.field_1350);
        float yaw   = (float) Math.toDegrees(Math.atan2(-d.field_1352, d.field_1350));
        float pitch = (float) -Math.toDegrees(Math.atan2(d.field_1351, hDist));
        player.method_36456(yaw);
        player.method_36457(class_3532.method_15363(pitch, -90f, 90f));
    }

    private static void reset() { fired = false; lastTarget = null; }
}
