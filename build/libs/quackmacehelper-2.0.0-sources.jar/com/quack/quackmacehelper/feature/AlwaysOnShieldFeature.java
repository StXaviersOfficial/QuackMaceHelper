package com.quack.quackmacehelper.feature;

import com.quack.quackmacehelper.config.ModConfig;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * AlwaysOnShield: When a threat is detected within 10 blocks (falling/gliding toward user),
 * equips shield (or totem if no shield) and holds it until threat lands.
 * Doesn't interfere if user manually switches.
 */
public class AlwaysOnShieldFeature {

    private static class_1309 activeTarget = null;
    private static int prevSlot = -1;
    private static boolean active = false;

    public static void tick(class_310 client) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.alwaysOnShield.enabled) { deactivate(client); return; }
        if (client.field_1724 == null) return;

        class_746 player = client.field_1724;

        // Find threat
        class_1309 threat = findThreat(client, cfg.alwaysOnShield.radius);

        if (threat == null) {
            if (active) deactivate(client);
            return;
        }

        activeTarget = threat;

        // If threat has landed, deactivate
        if (threat.method_24828()) {
            deactivate(client);
            return;
        }

        if (!active) activate(client, player);

        // Keep AimAssist toward threat
        AimAssistFeature.forceTarget(threat);
    }

    public static void activateFor(class_1309 target) {
        activeTarget = target;
    }

    private static void activate(class_310 client, class_746 player) {
        // Find shield in hotbar
        int shieldSlot = findShieldSlot(player);
        int totemSlot  = findTotemSlot(player);

        if (shieldSlot != -1) {
            prevSlot = player.method_31548().method_67532();
            InventoryHelper.switchToSlot(client, shieldSlot);
            client.field_1761.method_2919(player, class_1268.field_5808);
            active = true;
        } else if (totemSlot != -1) {
            prevSlot = player.method_31548().method_67532();
            InventoryHelper.switchToSlot(client, totemSlot);
            active = true;
        }
    }

    private static void deactivate(class_310 client) {
        if (active && prevSlot != -1 && client.field_1724 != null) {
            // Only switch back if player hasn't manually changed slot
            InventoryHelper.switchToSlot(client, prevSlot);
        }
        active = false;
        prevSlot = -1;
        activeTarget = null;
    }

    private static class_1309 findThreat(class_310 client, float radius) {
        class_1309 t = activeTarget != null && activeTarget.method_5805()
                ? activeTarget
                : TargetHelper.findPlayerTarget(client, radius);
        if (t == null) return null;
        boolean falling = !t.method_24828() && t.method_18798().field_1351 < -0.1;
        boolean gliding = t instanceof net.minecraft.class_1657 pe && pe.method_6128();
        if (!falling && !gliding) return null;
        if (!TargetHelper.isMovingToward(client, t)) return null;
        return t;
    }

    private static int findShieldSlot(class_746 player) {
        for (int i = 0; i < 9; i++) {
            if (player.method_31548().method_5438(i).method_7909() == class_1802.field_8255) return i;
        }
        return -1;
    }

    private static int findTotemSlot(class_746 player) {
        for (int i = 0; i < 9; i++) {
            if (player.method_31548().method_5438(i).method_7909() == class_1802.field_8288) return i;
        }
        return -1;
    }
}
