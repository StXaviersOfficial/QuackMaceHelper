package com.quack.quackmacehelper.feature;

import com.quack.quackmacehelper.config.ModConfig;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1684;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;

/**
 * PearlCatch: When YOUR pearl goes above triggerHeight blocks,
 * calculates exact intercept point, aims there, fires exactly 1 wind charge.
 */
public class PearlCatchFeature {

    private static class_1684 trackedPearl = null;
    private static int countdown = -1;
    private static boolean fired = false;

    // Wind charge approximate speed (blocks per tick)
    private static final double WIND_CHARGE_SPEED = 1.5;

    public static void tick(class_310 client) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.pearlCatch.enabled) { reset(); return; }
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_746 player = client.field_1724;

        // Find our pearl
        if (trackedPearl == null || !trackedPearl.method_5805()) {
            trackedPearl = findOurPearl(client);
            fired = false;
            countdown = -1;
            return;
        }

        if (fired) return;

        double heightAbovePlayer = trackedPearl.method_23318() - player.method_23318();
        if (heightAbovePlayer < cfg.pearlCatch.triggerHeight) return;

        // Check we have wind charge
        int wcSlot = InventoryHelper.findWindChargeSlot(player);
        if (wcSlot == -1) { reset(); return; }

        // Start countdown
        if (countdown == -1) {
            countdown = cfg.pearlCatch.delayTicks;
        }

        if (countdown > 0) {
            countdown--;
            return;
        }

        // Fire! Calculate intercept
        // Estimate travel time for wind charge to reach current pearl distance
        double dist = player.method_5739(trackedPearl);
        int travelTicks = Math.max(1, (int)(dist / WIND_CHARGE_SPEED));

        // Predict pearl position at that time
        class_243 intercept = predictPearl(trackedPearl, travelTicks);

        // Aim exactly at intercept
        aimAt(client, player, intercept);

        // Switch to wind charge and fire
        InventoryHelper.switchToSlot(client, wcSlot);
        client.field_1761.method_2919(player, class_1268.field_5808);

        fired = true;
    }

    private static class_243 predictPearl(class_1684 pearl, int ticks) {
        double x = pearl.method_23317(), y = pearl.method_23318(), z = pearl.method_23321();
        double vx = pearl.method_18798().field_1352;
        double vy = pearl.method_18798().field_1351;
        double vz = pearl.method_18798().field_1350;
        double gravity = 0.03;
        double drag = 0.99;

        for (int i = 0; i < ticks; i++) {
            vy -= gravity;
            vx *= drag; vy *= drag; vz *= drag;
            x += vx; y += vy; z += vz;
        }
        return new class_243(x, y, z);
    }

    private static void aimAt(class_310 client, class_746 player, class_243 target) {
        class_243 d = target.method_1020(player.method_33571());
        double hDist = Math.sqrt(d.field_1352 * d.field_1352 + d.field_1350 * d.field_1350);
        float yaw   = (float) Math.toDegrees(Math.atan2(-d.field_1352, d.field_1350));
        float pitch = (float) -Math.toDegrees(Math.atan2(d.field_1351, hDist));
        player.method_36456(yaw);
        player.method_36457(class_3532.method_15363(pitch, -90f, 90f));
    }

    private static class_1684 findOurPearl(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return null;
        List<class_1684> list = client.field_1687.method_8390(
                class_1684.class,
                client.field_1724.method_5829().method_1014(128),
                p -> p.method_24921() == client.field_1724
        );
        return list.isEmpty() ? null : list.get(0);
    }

    private static void reset() {
        trackedPearl = null;
        countdown = -1;
        fired = false;
    }
}
