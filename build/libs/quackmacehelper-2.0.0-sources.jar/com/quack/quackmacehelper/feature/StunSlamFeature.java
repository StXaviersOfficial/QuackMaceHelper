package com.quack.quackmacehelper.feature;

import com.quack.quackmacehelper.config.ModConfig;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * StunSlam: When opponent's shield is detected (before it breaks) and player is falling,
 * hits with current weapon → axe → mace in 2 ticks.
 */
public class StunSlamFeature {

    private static int phase = 0;
    private static class_1309 target = null;
    private static int tickDelay = 0;

    public static void tick(class_310 client) {
        ModConfig cfg = ModConfig.get();
        // StunSlam disabled when ShieldDraining is on
        if (!cfg.stunSlam.enabled || cfg.shieldDraining.enabled) { reset(); return; }
        if (client.field_1724 == null) return;

        class_746 player = client.field_1724;

        if (phase == 0) {
            class_1309 t = AimAssistFeature.getCurrentTarget();
            if (t == null) return;
            if (!player.method_24828() && player.field_6017 >= 1.5f
                    && InventoryHelper.isHoldingShield(t)
                    && player.method_5739(t) <= 3.5f) {
                target = t;
                phase = 1;
                tickDelay = 0;
            }
            return;
        }

        if (tickDelay > 0) { tickDelay--; return; }
        if (target == null || !target.method_5805() || player.method_24828()) { reset(); return; }

        switch (phase) {
            case 1 -> {
                // Hit with current weapon
                client.field_1761.method_2918(player, target);
                // Switch to axe
                int axe = InventoryHelper.findAxeSlot(player);
                if (axe != -1) InventoryHelper.switchToSlot(client, axe);
                phase = 2; tickDelay = 0;
            }
            case 2 -> {
                // Hit with axe
                client.field_1761.method_2918(player, target);
                // Switch to mace
                int mace = InventoryHelper.pickBestMaceSlot(player, player.field_6017, target.method_6096());
                if (mace != -1) InventoryHelper.switchToSlot(client, mace);
                phase = 3; tickDelay = 1;
            }
            case 3 -> {
                // Hit with mace
                client.field_1761.method_2918(player, target);
                reset();
            }
        }
    }

    public static void triggerIndependent(class_310 client, class_1309 t) {
        if (client.field_1724 == null || t == null) return;
        target = t;
        phase = 1;
        tickDelay = 0;
    }

    private static void reset() { phase = 0; target = null; tickDelay = 0; }
}
