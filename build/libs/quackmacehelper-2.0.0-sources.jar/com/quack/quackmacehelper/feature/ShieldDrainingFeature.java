package com.quack.quackmacehelper.feature;

import com.quack.quackmacehelper.config.ModConfig;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * ShieldDraining: While falling and target has shield up within 3 blocks,
 * hits with mace at set CPS. Stops ~0.5 blocks from ground, switches back to sword.
 */
public class ShieldDrainingFeature {

    private static long lastHitMs = 0;
    private static int prevSlot = -1;

    // Approximate: stop when fall distance indicates we're near ground
    private static final float STOP_FALL_DIST = 0.5f;

    public static void tick(class_310 client) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.shieldDraining.enabled) { prevSlot = -1; return; }
        if (client.field_1724 == null) return;

        class_746 player = client.field_1724;

        // Only while falling
        if (player.method_24828()) {
            if (prevSlot != -1) {
                InventoryHelper.switchToSlot(client, prevSlot);
                prevSlot = -1;
            }
            return;
        }

        // Stop near ground — velocity approaching 0 from below or tiny fall distance remaining
        double vy = player.method_18798().field_1351;
        if (vy > -0.08 && player.field_6017 > 0.5f) {
            if (prevSlot != -1) {
                InventoryHelper.switchToSlot(client, prevSlot);
                prevSlot = -1;
            }
            return;
        }

        class_1309 target = AimAssistFeature.getCurrentTarget();
        if (target == null) return;
        if (!InventoryHelper.isHoldingShield(target)) return;
        if (player.method_5739(target) > 3.0f) return;

        // Find sword slot to remember
        if (prevSlot == -1) {
            int sword = InventoryHelper.findSwordSlot(player);
            prevSlot = sword != -1 ? sword : player.method_31548().method_67532();
        }

        long nowMs = System.currentTimeMillis();
        long intervalMs = 1000L / cfg.shieldDraining.cps;
        long variance = (long)(Math.random() * 10 - 5);
        if (nowMs - lastHitMs < intervalMs + variance) return;

        int mace = InventoryHelper.findAnyMaceSlot(player);
        if (mace == -1) return;

        InventoryHelper.switchToSlot(client, mace);
        client.field_1761.method_2918(player, target);
        lastHitMs = nowMs;
    }
}
