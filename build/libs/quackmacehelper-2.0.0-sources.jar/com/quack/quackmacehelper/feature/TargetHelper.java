package com.quack.quackmacehelper.feature;

import com.quack.quackmacehelper.config.ModConfig;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class TargetHelper {

    public static class_1309 findTarget(class_310 client, double radius) {
        if (client.field_1724 == null || client.field_1687 == null) return null;
        ModConfig cfg = ModConfig.get();

        class_238 box = client.field_1724.method_5829().method_1014(radius);
        List<class_1309> candidates = new ArrayList<>();

        for (class_1309 e : client.field_1687.method_8390(class_1309.class, box, en -> true)) {
            if (e == client.field_1724) continue;
            if (!e.method_5805()) continue;
            if (!isValidTarget(e, cfg)) continue;
            if (e.method_5739(client.field_1724) > radius) continue;
            candidates.add(e);
        }

        if (candidates.isEmpty()) return null;

        // Default: lowest health
        return candidates.stream()
                .min(Comparator.comparingDouble(class_1309::method_6032))
                .orElse(null);
    }

    /** Finds target within given radius, players only (for WindChargeTackle / AlwaysOnShield) */
    public static class_1309 findPlayerTarget(class_310 client, double radius) {
        if (client.field_1724 == null || client.field_1687 == null) return null;
        class_238 box = client.field_1724.method_5829().method_1014(radius);
        return client.field_1687.method_8390(class_1657.class, box,
                e -> e != client.field_1724 && e.method_5805() && e.method_5739(client.field_1724) <= radius)
                .stream()
                .min(Comparator.comparingDouble(e -> e.method_5739(client.field_1724)))
                .orElse(null);
    }

    public static boolean isValidTarget(class_1309 e, ModConfig cfg) {
        if (e instanceof class_1657) return cfg.targetPlayers;
        if (e instanceof class_1429)  return cfg.targetAnimals;
        if (e instanceof class_1308)     return cfg.targetMobs;
        return false;
    }

    /** Checks if entity is within fovDegrees cone around player's look direction */
    public static boolean isInFov(class_310 client, class_1309 entity, float fovDeg) {
        if (client.field_1724 == null) return false;
        if (fovDeg >= 360f) return true;
        double angle = angleToEntity(client, entity);
        return angle <= fovDeg / 2.0;
    }

    public static double angleToEntity(class_310 client, class_1309 entity) {
        if (client.field_1724 == null) return Double.MAX_VALUE;
        class_243 look = client.field_1724.method_5828(1.0f);
        class_243 toEntity = entity.method_73189().method_1020(client.field_1724.method_33571()).method_1029();
        double dot = Math.max(-1.0, Math.min(1.0, look.method_1026(toEntity)));
        return Math.toDegrees(Math.acos(dot));
    }

    /** Returns true if the entity appears to be moving/flying toward the client player */
    public static boolean isMovingToward(class_310 client, class_1309 entity) {
        if (client.field_1724 == null) return false;
        class_243 vel = entity.method_18798();
        if (vel.method_1027() < 0.001) return false;
        class_243 toPlayer = client.field_1724.method_73189().method_1020(entity.method_73189()).method_1029();
        return vel.method_1029().method_1026(toPlayer) > 0.5;
    }
}
