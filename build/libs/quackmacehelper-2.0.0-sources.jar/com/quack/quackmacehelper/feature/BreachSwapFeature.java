package com.quack.quackmacehelper.feature;

import com.quack.quackmacehelper.config.ModConfig;
import net.minecraft.class_1309;
import net.minecraft.class_1743;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_746;

/**
 * BreachSwap: On sword/axe hit → switch to mace → hit again (same tick) → switch back to sword next tick.
 */
public class BreachSwapFeature {

    private static int switchBackCountdown = 0;
    private static int prevSlot = -1;

    public static void onAttack(class_310 client, class_1309 target) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.breachSwap.enabled) return;
        if (client.field_1724 == null) return;

        class_746 player = client.field_1724;
        boolean holdingSword = player.method_6047().method_31573(class_3489.field_42611);
        boolean holdingAxe   = player.method_6047().method_7909() instanceof class_1743;
        if (!holdingSword && !holdingAxe) return;

        prevSlot = player.method_31548().method_67532();
        boolean inAir = !player.method_24828();

        int maceSlot = inAir
                ? InventoryHelper.findDensityMaceSlot(player)
                : InventoryHelper.findBreachMaceSlot(player);
        if (maceSlot == -1) maceSlot = InventoryHelper.findAnyMaceSlot(player);
        if (maceSlot == -1) return;

        InventoryHelper.switchToSlot(client, maceSlot);
        client.field_1761.method_2918(player, target);

        switchBackCountdown = 1; // switch back next tick
    }

    public static void tick(class_310 client) {
        if (switchBackCountdown <= 0 || prevSlot == -1) return;
        switchBackCountdown--;
        if (switchBackCountdown == 0) {
            InventoryHelper.switchToSlot(client, prevSlot);
            prevSlot = -1;
        }
    }
}
