package com.quack.quackmacehelper.feature;

import com.quack.quackmacehelper.config.ModConfig;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * ElytraSwapper: While gliding with elytra, if target enters hit range:
 * - Equip chestplate (from hotbar) → hit with mace 4-5 times in ~2 ticks
 * - If target has shield → auto stun slam (independent)
 * - AutoAim at max speed during sequence
 */
public class ElytraSwapperFeature {

    private static int phase = 0;
    private static int tickDelay = 0;
    private static class_1309 target = null;
    private static int hitCount = 0;
    private static final int MAX_HITS = 5;

    public static void tick(class_310 client) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.elytraSwapper.enabled) { reset(); return; }
        if (client.field_1724 == null) return;

        class_746 player = client.field_1724;

        // Must be gliding with elytra
        if (!player.method_6128()) { reset(); return; }

        if (phase == 0) {
            class_1309 t = findTarget(client, cfg);
            if (t == null) return;
            target = t;
            phase = 1;
            tickDelay = 0;
        }

        if (tickDelay > 0) { tickDelay--; return; }
        if (target == null || !target.method_5805()) { reset(); return; }

        // AutoAim at max speed toward target
        if (cfg.elytraSwapper.autoAim) {
            AimAssistFeature.smoothAimAt(client, target, 7200f, 0.05f, false, 0f);
        }

        switch (phase) {
            case 1 -> {
                // Equip chestplate from hotbar
                int chestSlot = findChestplateSlot(player);
                if (chestSlot == -1) { reset(); return; }
                InventoryHelper.switchToSlot(client, chestSlot);
                client.field_1761.method_2919(player, class_1268.field_5808);
                phase = 2; tickDelay = 1;
            }
            case 2 -> {
                // Check shield — if shielding, do stun slam
                if (InventoryHelper.isHoldingShield(target)) {
                    StunSlamFeature.triggerIndependent(client, target);
                    reset();
                    return;
                }
                // Switch to mace and start hitting
                int mace = InventoryHelper.pickBestMaceSlot(player, player.field_6017, target.method_6096());
                if (mace == -1) { reset(); return; }
                InventoryHelper.switchToSlot(client, mace);
                phase = 3; hitCount = 0; tickDelay = 0;
            }
            case 3 -> {
                // Hit rapidly — 4-5 times
                if (player.method_5739(target) <= 3.5f && target.method_5805()) {
                    client.field_1761.method_2918(player, target);
                    hitCount++;
                }
                if (hitCount >= MAX_HITS || !target.method_5805()) {
                    reset();
                } else {
                    tickDelay = 0; // hit again next tick
                }
            }
        }
    }

    private static class_1309 findTarget(class_310 client, ModConfig cfg) {
        if (client.field_1724 == null) return null;
        // Use aim assist target if available and in FOV
        class_1309 aaTarget = AimAssistFeature.getCurrentTarget();
        if (aaTarget != null && client.field_1724.method_5739(aaTarget) <= 3.5f) return aaTarget;
        // Otherwise find closest in FOV
        return TargetHelper.findTarget(client, 3.5);
    }

    private static int findChestplateSlot(class_746 player) {
        for (int i = 0; i < 9; i++) {
            var stack = player.method_31548().method_5438(i);
            var item = stack.method_7909();
            if (item == class_1802.field_22028 || item == class_1802.field_8058
                    || item == class_1802.field_8523 || item == class_1802.field_8678
                    || item == class_1802.field_8873 || item == class_1802.field_8577) {
                return i;
            }
        }
        return -1;
    }

    private static void reset() { phase = 0; tickDelay = 0; target = null; hitCount = 0; }
}
